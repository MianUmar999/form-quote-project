/* ==========================================================================
   BRAND FORMS JS – Eagle Wing Marketing
   v1.0  |  Unifies logic for:
           1) Listing/Options (Levels + Add-ons + Confirm Popup)
           2) Instant Quote (dark card)
           3) Instruction Multi-step (stepper + signature + submit)
   Notes:
   - Same phone validation on all <input type="tel"> using intl-tel-input if available
     with a safe fallback to E.164-style check.
   - No flashy hover/focus animations (CSS already stripped) – runtime validation only.
   - AJAX-style UX: loaders + no full-page white screens.
   - Iframe height auto-postMessage (for future embedding).
   ========================================================================== */

(function () {
  'use strict';

  // -----------------------------
  // Utilities
  // -----------------------------
  const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));
  const $  = (sel, ctx = document) => ctx.querySelector(sel);

  const currencySymbol = '£';

  const formatMoney = (n) => {
    const v = Number(n || 0);
    return currencySymbol + v.toLocaleString('en-GB', { maximumFractionDigits: 0 });
  };

  const parseMoneyFromText = (txt) => {
    if (!txt) return 0;
    const m = txt.replace(/[^\d.]/g, '');
    return parseInt(m || '0', 10) || 0;
  };

  const throttle = (fn, wait = 120) => {
    let last = 0, t;
    return (...args) => {
      const now = Date.now();
      if (now - last >= wait) {
        last = now; fn.apply(null, args);
      } else {
        clearTimeout(t);
        t = setTimeout(() => { last = Date.now(); fn.apply(null, args); }, wait - (now - last));
      }
    };
  };

  const postFrameHeight = throttle(() => {
    try {
      const h = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
      window.parent && window.parent.postMessage({ frameHeight: h }, '*');
    } catch (_) {}
  }, 150);

  const on = (el, evt, handler, opts) => el && el.addEventListener(evt, handler, opts);
  const off = (el, evt, handler) => el && el.removeEventListener(evt, handler);

  // Runtime field state
  const setInvalid = (input, msg) => {
    if (!input) return;
    input.classList.add('is-invalid');
    input.setAttribute('aria-invalid', 'true');
    if (msg) showErrorBelow(input, msg);
  };
  const clearInvalid = (input) => {
    if (!input) return;
    input.classList.remove('is-invalid');
    input.removeAttribute('aria-invalid');
    removeErrorBelow(input);
  };

  const showErrorBelow = (input, message) => {
    removeErrorBelow(input);
    const small = document.createElement('div');
    small.className = 'error-text';
    small.textContent = message;
    input.insertAdjacentElement('afterend', small);
  };

  const removeErrorBelow = (input) => {
    const nxt = input && input.nextElementSibling;
    if (nxt && nxt.classList.contains('error-text')) nxt.remove();
  };

  // -----------------------------
  // Phone validation (intl-tel-input if present)
  // -----------------------------
  const Phone = {
    instances: new Map(),

    initAll() {
      $$('input[type="tel"]').forEach((input) => {
        this.initOne(input);
      });
    },

    initOne(input) {
      if (!input || Phone.instances.has(input)) return;

      // Attempt to attach intlTelInput if available
      let iti = null;
      const hasITI = !!(window.intlTelInput && typeof window.intlTelInput === 'function');

      if (hasITI) {
        // If already initialized elsewhere, do not re-init
        if (input._iti) {
          iti = input._iti;
        } else {
          const initialCountry = input.dataset.country || 'GB';
          try {
            iti = window.intlTelInput(input, {
              initialCountry,
              preferredCountries: ['GB', 'US', 'CA', 'AU'],
              // Avoid extra network calls for utils unless page already loaded them
              utilsScript: (window.intlTelInputUtils ? '' :
                'https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.19/js/utils.js')
            });
            input._iti = iti;
          } catch (_) {
            iti = null;
          }
        }
      }

      // Live validation UI
      const _validateUI = () => {
        const ok = Phone.isValid(input);
        if (ok) { clearInvalid(input); input.classList.add('is-valid'); }
        else { input.classList.remove('is-valid'); }
      };

      on(input, 'blur', _validateUI);
      on(input, 'input', () => { removeErrorBelow(input); });
      on(input, 'countrychange', _validateUI);

      Phone.instances.set(input, { input, iti });
    },

    isValid(input) {
      const rec = Phone.instances.get(input);
      if (!rec) return Phone.fallbackValid(input.value);

      const { iti } = rec;
      if (iti && typeof iti.isValidNumber === 'function') {
        try { return iti.isValidNumber(); } catch (_) { /* ignore */ }
      }
      return Phone.fallbackValid(input.value);
    },

    getE164(input) {
      const rec = Phone.instances.get(input);
      if (rec && rec.iti && typeof rec.iti.getNumber === 'function') {
        try {
          const n = rec.iti.getNumber();
          if (n) return n;
        } catch (_) {}
      }
      // Fallback: strip non-digits, prepend + if missing
      const d = (input.value || '').replace(/[^\d]/g, '');
      if (!d) return '';
      return d.startsWith('0') ? `+44${d.slice(1)}` : (d.startsWith('+') ? d : `+${d}`);
    },

    fallbackValid(value) {
      // Simple E.164-ish sanity check
      const v = (value || '').replace(/\s+/g, '');
      return /^\+?\d{7,15}$/.test(v);
    }
  };

  // -----------------------------
  // 1) Listing / Options Page
  // -----------------------------
  const Listing = {
    els: {},

    init() {
      const container = $('#quote-container');
      if (!container) return;

      // Cache elements
      this.els.step1 = container.querySelector('.step-1');
      this.els.step2 = container.querySelector('.step-2');
      this.els.levelChoices = $$('.level-choice', container);
      this.els.addonSelects = $$('.addon', container);
      this.els.level3Total = container.querySelector('.step-2 .level-price.addons');
      this.els.level3Base = $('#level3-base-price') || null;
      this.els.level4Base = $('#level4-base-price') || null;
      this.els.level4UpsellWrap = container.querySelector('.level4-all-inlcude-addons');
      this.els.level4SaveSpan = container.querySelector('.save-price');
      this.els.confirmWrap = $('#confirm-popup-conteiner');
      this.els.confirmYes = this.els.confirmWrap ? this.els.confirmWrap.querySelector('.confirm-yes') : null;
      this.els.termsCheckbox = $('#termsCheckbox');

      // Card selection highlight
      this.els.levelChoices.forEach((card) => {
        on(card, 'click', () => {
          this.els.levelChoices.forEach(c => c.classList.remove('selected'));
          card.classList.add('selected');
        });
      });

      // Buy Now buttons
      $$('.buy-now-btn', container).forEach((btn) => {
        const level = btn.dataset.level;
        on(btn, 'click', (e) => {
          e.preventDefault();
          Listing.handleBuy(btn, level);
        });
      });

      // Add-ons calc
      this.els.addonSelects.forEach((sel) => on(sel, 'change', () => this.updateLevel3Price()));
      this.updateLevel3Price();

      // Popup buttons
      on($('.confirm-popup-close', this.els.confirmWrap), 'click', Listing.closePopup);
      on(this.els.confirmYes, 'click', Listing.proceed);

      // Iframe autosize
      postFrameHeight();
      on(window, 'load', postFrameHeight);
      on(window, 'resize', postFrameHeight);
      if ('ResizeObserver' in window) {
        const ro = new ResizeObserver(postFrameHeight);
        ro.observe(document.body);
      }
    },

    getBasePrice(level) {
      if (String(level) === '3') {
        const base = this.els.level3Base ? parseInt(this.els.level3Base.value, 10) : parseMoneyFromText($('.level3-price')?.textContent);
        return isNaN(base) ? 0 : base;
      }
      if (String(level) === '4') {
        const base = this.els.level4Base ? parseInt(this.els.level4Base.value, 10) : parseMoneyFromText($('.level4-price')?.textContent);
        return isNaN(base) ? 0 : base;
      }
      // Level 1/2 come from text
      return parseMoneyFromText($(`.level${level}-price`)?.textContent);
    },

    updateLevel3Price() {
      const base = this.getBasePrice(3);
      let total = base;
      let selected = 0;
      const selects = this.els.addonSelects;

      selects.forEach(s => {
        const cost = parseInt(s.dataset.cost || '0', 10);
        if (String(s.value) === '1') { total += cost; selected++; }
      });

      if (this.els.level3Total) this.els.level3Total.textContent = formatMoney(total);

      // Upsell to Level 3+ if all addons selected and total > level4 base
      const totalAdd = selects.length;
      const level4 = this.getBasePrice(4);
      if (selected === totalAdd && total > level4) {
        if (this.els.level4SaveSpan) this.els.level4SaveSpan.textContent = formatMoney(total - level4);
        if (this.els.level4UpsellWrap) this.els.level4UpsellWrap.style.display = 'block';
      } else {
        if (this.els.level4UpsellWrap) this.els.level4UpsellWrap.style.display = 'none';
      }

      postFrameHeight();
    },

    handleBuy(btn, level) {
      // Inline loader UI
      const loader = btn.querySelector('.btn-loader');
      const text = btn.querySelector('.btn-text');
      btn.classList.add('disabled');
      if (loader) loader.style.display = 'inline-block';
      if (text) { text.dataset.defaultText = text.textContent; text.textContent = 'Loading...'; }

      setTimeout(() => {
        btn.classList.remove('disabled');
        if (loader) loader.style.display = 'none';
        if (text) text.textContent = text.dataset.defaultText || 'Instruct & Pay';
        Listing.showConfirm(level);
      }, 400);
    },

    showConfirm(level) {
      Listing._selectedLevel = level;
      if (Listing.els.confirmWrap) Listing.els.confirmWrap.style.display = 'flex';
      postFrameHeight();
    },

    closePopup() {
      const wrap = Listing.els.confirmWrap;
      if (!wrap) return;
      wrap.style.display = 'none';
      const wait = $('#wait-notice');
      if (wait) wait.style.display = 'none';

      $$('.btn-style', wrap).forEach((btn) => {
        btn.classList.remove('disabled');
        const l = btn.querySelector('.btn-loader');
        const t = btn.querySelector('.btn-text');
        if (l) l.style.display = 'none';
        if (t) t.textContent = (t.dataset && t.dataset.defaultText) || t.textContent.replace('Loading...', 'Instruct & Pay').replace('Processing...', 'Proceed');
      });

      postFrameHeight();
    },

    proceed() {
      // Terms check
      if (Listing.els.termsCheckbox && !Listing.els.termsCheckbox.checked) {
        alert('Please agree to the terms and conditions.');
        return;
      }

      const btn = Listing.els.confirmYes;
      if (!btn) return;
      const loader = btn.querySelector('.btn-loader');
      const text = btn.querySelector('.btn-text');
      const wait = $('#wait-notice');

      btn.classList.add('disabled');
      if (loader) loader.style.display = 'inline-block';
      if (text) text.textContent = 'Processing...';
      if (wait) wait.style.display = 'block';

      // Simulate secure redirect (replace with real redirect/submit)
      setTimeout(() => {
        // Hook for integration:
        // window.location.assign('/secure-payment?level=' + encodeURIComponent(Listing._selectedLevel));
        alert(`Redirecting to payment page for Level ${Listing._selectedLevel}...`);
        Listing.closePopup();
      }, 1500);
    },

    // Public API (optional): show addons (from Level 3 card)
    showAddons() {
      const s1 = Listing.els.step1, s2 = Listing.els.step2;
      if (s1 && s2) {
        s1.style.display = 'none';
        s2.classList.add('active');
        setTimeout(postFrameHeight, 120);
      }
    },
    showStep1() {
      const s1 = Listing.els.step1, s2 = Listing.els.step2;
      if (s1 && s2) {
        s1.style.display = 'block';
        s2.classList.remove('active');
        postFrameHeight();
      }
    }
  };

  // Expose for inline onclicks, if old HTML still uses them:
  window.showAddons = () => Listing.showAddons();
  window.showStep1   = () => Listing.showStep1();

  // -----------------------------
  // 2) Instant Quote Form
  // -----------------------------
  const Quote = {
    form: null,

    init() {
      this.form = $('#quoteForm');
      if (!this.form) return;

      // Phone (same rules)
      const tel = $('#telephone_number', this.form);
      if (tel) {
        tel.dataset.country = 'GB';
        Phone.initOne(tel);
      }

      // Toggle sqft area
      const over = $('#over1650', this.form);
      const sqftBox = $('#sqftPriceBox', this.form);
      if (over && sqftBox) {
        const toggle = () => {
          sqftBox.style.display = over.checked ? 'block' : 'none';
          if (over.checked) {
            setTimeout(() => {
              const target = $('.footer-text', this.form);
              target && target.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }, 250);
          }
          postFrameHeight();
        };
        on(over, 'change', toggle);
        toggle();
      }

      // Google Places Autocomplete (optional)
      this.initPlacesAutocomplete();

      // Realtime runtime validation
      $$('input, select, textarea', this.form).forEach((f) => {
        on(f, 'blur', () => this.validateField(f));
        on(f, 'input', () => clearInvalid(f));
      });

      // Submit
      on(this.form, 'submit', (e) => this.handleSubmit(e));

      postFrameHeight();
    },

    initPlacesAutocomplete() {
      try {
        if (!(window.google && google.maps && google.maps.places)) return;
        const addressField = $('#full_address', this.form);
        if (!addressField) return;

        const ac = new google.maps.places.Autocomplete(addressField, {
          types: ['address'],
          componentRestrictions: { country: 'gb' }
        });

        // newer API auto-provides fields; safe to read full place
        ac.addListener('place_changed', () => {
          const place = ac.getPlace();
          if (place && place.formatted_address) {
            // strip trailing ", United Kingdom"/", UK"
            let val = place.formatted_address.replace(/,\s*(United Kingdom|UK)$/i, '');
            // extract postcode if present
            let postcode = '';
            if (place.address_components) {
              const pc = place.address_components.find(c => (c.types || []).includes('postal_code'));
              if (pc) postcode = String(pc.long_name || '').toUpperCase();
            }
            // remove postcode from the middle if duplicated
            if (postcode) {
              val = val.replace(new RegExp(`\\s*${postcode}\\s*`, 'i'), ' ').replace(/\s{2,}/g, ' ').trim();
              const hiddenPc = $('#postcode', this.form);
              if (hiddenPc) hiddenPc.value = postcode;
            }
            addressField.value = val;
          }
          postFrameHeight();
        });
      } catch (_) {}
    },

    validateField(field) {
      if (!field) return true;

      // Special case: phone
      if (field.type === 'tel') {
        const ok = Phone.isValid(field);
        if (!ok) { setInvalid(field, 'Please enter a valid phone number.'); return false; }
        clearInvalid(field);
        return true;
      }

      // Built-in validity
      if (!field.checkValidity()) {
        setInvalid(field, field.validationMessage || 'This field is required.');
        return false;
      }
      clearInvalid(field);
      return true;
    },

    validateForm() {
      let ok = true;
      // Required + visible
      $$('[required]', this.form).forEach((f) => {
        // Skip hidden sqft when toggle off
        if (f.closest('#sqftPriceBox') && $('#sqftPriceBox').style.display === 'none') return;
        if (!this.validateField(f)) ok = false;
      });

      // Terms
      const agree = $('#agree_terms', this.form);
      if (agree && !agree.checked) {
        ok = false;
        alert('Please agree to the terms and conditions.');
      }

      // Phone final check
      const tel = $('#telephone_number', this.form);
      if (tel && !Phone.isValid(tel)) {
        setInvalid(tel, 'Please enter a valid phone number.');
        ok = false;
      }
      return ok;
    },

    handleSubmit(e) {
      e.preventDefault();
      if (!this.validateForm()) return;

      // UI loaders
      const btn = $('#proceedBtn', this.form);
      const spinner = $('#loading', this.form);
      if (btn) btn.style.display = 'none';
      if (spinner) spinner.style.display = 'block';

      // Normalize phone E.164
      const tel = $('#telephone_number', this.form);
      if (tel) tel.value = Phone.getE164(tel);

      // Collect payload
      const data = new FormData(this.form);

      // Hook: replace with real endpoint if needed
      const fakePost = () => new Promise((res) => setTimeout(res, 1200));

      fakePost().then(() => {
        alert('Quote submitted successfully! Redirecting...');
        // Example: window.location.assign('/quote/thank-you');
      }).finally(() => {
        if (btn) btn.style.display = 'inline-block';
        if (spinner) spinner.style.display = 'none';
      });
    }
  };

  // -----------------------------
  // 3) Instruction Multi-Step Form
  // -----------------------------
  const Steps = {
    form: null,
    current: 1,
    total: 6,
    sig: { drawing: false, data: '' },

    init() {
      this.form = $('#surveyForm');
      if (!this.form) return;

      // Progress nav
      on($('#nextBtn', this.form), 'click', () => this.next());
      on($('#prevBtn', this.form), 'click', () => this.prev());
      on($('#submitBtn', this.form), 'click', (e) => this.submit(e));

      $$('.progress-step', this.form.closest('.form-container') || document).forEach((node) => {
        on(node, 'click', () => {
          const n = parseInt(node.dataset.step, 10);
          if (Number.isFinite(n) && this.canGoTo(n)) this.go(n);
        });
      });

      // Conditional fields
      this.initConditionalFields();

      // Realtime validation
      $$('input, select, textarea', this.form).forEach((f) => {
        on(f, 'blur', () => this.validateField(f));
        on(f, 'input', () => clearInvalid(f));
      });

      // Phone fields → same validation
      $$('input[type="tel"]', this.form).forEach((tel) => {
        tel.dataset.country = 'GB';
        Phone.initOne(tel);
      });

      // Signature
      this.initSignature();

      // Keyboard shortcuts
      on(document, 'keydown', (e) => {
        if (!this.form.contains(document.activeElement)) return;
        if (e.ctrlKey && e.key === 'ArrowRight') this.next();
        if (e.ctrlKey && e.key === 'ArrowLeft')  this.prev();
        if (e.ctrlKey && e.key === 'Enter') {
          if (this.current < this.total) this.next();
          else this.submit(e);
        }
      });

      this.updateUI();
      postFrameHeight();
    },

    // ---- Conditional fields
    initConditionalFields() {
      // Garage → location
      $$('input[name="inf_custom_Garage"]', this.form).forEach((r) => {
        on(r, 'change', () => {
          const show = r.value === '1' && r.checked;
          const fld = $('#garageLocationField', this.form);
          if (fld) fld.style.display = show ? 'block' : 'none';
          postFrameHeight();
        });
      });

      // Garden → location
      $$('input[name="inf_custom_Garden"]', this.form).forEach((r) => {
        on(r, 'change', () => {
          const show = r.value === '1' && r.checked;
          const fld = $('#gardenLocationField', this.form);
          if (fld) fld.style.display = show ? 'block' : 'none';
          postFrameHeight();
        });
      });

      // Solicitor block
      $$('input[name="inf_custom_SolicitorFirm"]', this.form).forEach((r) => {
        on(r, 'change', () => {
          const wrap = $('#solicitorFields', this.form);
          if (!wrap) return;
          const requireds = $$('input[required]', wrap);
          const show = r.value === 'yes' && r.checked;
          wrap.style.display = show ? 'block' : 'none';
          requireds.forEach(f => f.required = show);
          postFrameHeight();
        });
      });

      // Exchange date
      $$('input[name="inf_custom_exchange_known"]', this.form).forEach((r) => {
        on(r, 'change', () => {
          const wrap = $('#exchangeDateField', this.form);
          const input = $('#exchangeDate', this.form);
          const show = r.value === 'yes' && r.checked;
          if (wrap) wrap.style.display = show ? 'block' : 'none';
          if (input) input.required = !!show;
          postFrameHeight();
        });
      });
    },

    // ---- Stepper
    canGoTo(step) {
      return step <= this.current + 1 && (step <= this.current || this.validateStep(this.current));
    },
    go(step) {
      this.current = Math.min(Math.max(1, step), this.total);
      this.updateUI();
    },
    next() {
      if (!this.validateStep(this.current)) return;
      if (this.current < this.total) { this.current++; this.updateUI(); }
    },
    prev() { if (this.current > 1) { this.current--; this.updateUI(); } },

    updateUI() {
      // Steps
      for (let i = 1; i <= this.total; i++) {
        const el = document.getElementById(`step${i}`);
        if (el) el.classList.toggle('active', i === this.current);
      }

      // Progress bar
      const pb = $('.progress-bar');
      if (pb) pb.setAttribute('data-progress', String(this.current));
      $$('.progress-step').forEach((node, idx) => {
        node.classList.toggle('active', idx + 1 === this.current);
        node.classList.toggle('completed', idx + 1 < this.current);
      });

      // Nav buttons
      const prevBtn = $('#prevBtn', this.form);
      const nextBtn = $('#nextBtn', this.form);
      const submitBtn = $('#submitBtn', this.form);

      if (prevBtn) prevBtn.style.display = this.current > 1 ? 'block' : 'none';
      if (nextBtn) nextBtn.style.display = this.current === this.total ? 'none' : 'block';
      if (submitBtn) submitBtn.style.display = this.current === this.total ? 'block' : 'none';

      // Scroll container into view (smooth, no white flash)
      const cont = this.form.closest('.form-container');
      cont && cont.scrollIntoView({ behavior: 'smooth', block: 'start' });

      postFrameHeight();
    },

    // ---- Validation
    validateField(field) {
      if (!field) return true;

      if (field.type === 'tel') {
        const ok = Phone.isValid(field);
        if (!ok) { setInvalid(field, 'Please enter a valid phone number.'); return false; }
        clearInvalid(field); return true;
      }

      if (!field.checkValidity()) {
        setInvalid(field, field.validationMessage || 'This field is required.');
        return false;
      }
      clearInvalid(field);
      return true;
    },

    validateStep(step) {
      const pane = document.getElementById(`step${step}`);
      if (!pane) return true;

      let ok = true;
      const req = $$('[required]', pane);
      req.forEach((f) => {
        if (!this.validateField(f)) ok = false;
      });

      // Step 6 signature check
      if (step === 6) {
        const typed = ($('#typedName', this.form)?.value || '').trim();
        if (!this.sig.data && !typed) {
          ok = false;
          this.showInlineError(pane, 'Please provide either a signature or type your name.');
        } else {
          this.clearInlineError(pane);
        }

        // Terms checkbox on final step
        const terms = $('#termsCheckbox', this.form);
        if (terms && !terms.checked) {
          ok = false;
          alert('Please confirm you have read the Terms of Engagement.');
        }
      }

      if (!ok) this.showInlineError(pane, 'Please fill in all required fields before continuing.');
      else this.clearInlineError(pane);

      return ok;
    },

    showInlineError(pane, message) {
      if (!pane) return;
      let box = pane.querySelector('.error-message');
      if (!box) {
        box = document.createElement('div');
        box.className = 'error-message';
        box.style.cssText = `
          background: rgba(255, 107, 107, .10);
          border: 2px solid rgba(255, 107, 107, .30);
          color: #ff6b6b;
          padding: 12px 14px;
          border-radius: 8px;
          margin: 14px 0;
          text-align: center;
          font-weight: 600;
        `;
        pane.appendChild(box);
      }
      box.textContent = message;
      box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      setTimeout(() => box && box.remove(), 5000);
    },
    clearInlineError(pane) {
      const box = pane && pane.querySelector('.error-message');
      box && box.remove();
    },

    // ---- Signature pad
    initSignature() {
      const canvas = $('#signatureCanvas', this.form);
      if (!canvas) return;
      const inputHidden = $('#signatureInput', this.form);
      const typed = $('#typedName', this.form);
      const clearBtn = $('#clearSignatureBtn', this.form);

      const ctx = canvas.getContext('2d');
      ctx.strokeStyle = '#93c120';
      ctx.lineWidth = 2;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      const pos = (e) => {
        const r = canvas.getBoundingClientRect();
        const x = (e.clientX ?? e.touches?.[0]?.clientX) - r.left;
        const y = (e.clientY ?? e.touches?.[0]?.clientY) - r.top;
        return { x, y };
      };

      const start = (e) => {
        e.preventDefault();
        this.sig.drawing = true;
        const p = pos(e);
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
      };
      const move = (e) => {
        if (!this.sig.drawing) return;
        e.preventDefault();
        const p = pos(e);
        ctx.lineTo(p.x, p.y);
        ctx.stroke();
        this.updateSignatureData(canvas, inputHidden);
      };
      const stop = () => {
        if (this.sig.drawing) {
          this.sig.drawing = false;
          this.updateSignatureData(canvas, inputHidden);
        }
      };

      // Mouse
      on(canvas, 'mousedown', start);
      on(canvas, 'mousemove', move);
      on(canvas, 'mouseup', stop);
      on(canvas, 'mouseleave', stop);

      // Touch
      on(canvas, 'touchstart', start, { passive: false });
      on(canvas, 'touchmove', move, { passive: false });
      on(canvas, 'touchend', stop);

      // Typed name mirrors into canvas
      on(typed, 'input', () => {
        // Clear and draw name
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        const val = (typed.value || '').trim();
        if (val) {
          ctx.font = '24px "Poppins", sans-serif';
          ctx.fillStyle = '#93c120';
          ctx.textAlign = 'center';
          ctx.fillText(val, canvas.width / 2, canvas.height / 2 + 8);
        }
        this.updateSignatureData(canvas, inputHidden);
      });

      // Clear button
      on(clearBtn, 'click', () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        if (typed) typed.value = '';
        this.sig.data = '';
        if (inputHidden) inputHidden.value = '';
      });
    },

    updateSignatureData(canvas, hidden) {
      try {
        this.sig.data = canvas.toDataURL('image/png');
        if (hidden) hidden.value = this.sig.data;
      } catch (_) {}
    },

    // ---- Submit
    submit(e) {
      e.preventDefault();
      if (!this.validateStep(this.current)) return;

      // Final all-steps validation just in case
      for (let i = 1; i <= this.total; i++) {
        if (!this.validateStep(i)) { this.go(i); return; }
      }

      // Splash overlay
      const splash = $('#pageSplashLoader');
      if (splash) splash.style.display = 'flex';

      const fd = new FormData(this.form);

      // Normalize any tel fields to E.164
      $$('input[type="tel"]', this.form).forEach((t) => {
        const e164 = Phone.getE164(t);
        if (e164) fd.set(t.name || 'phone', e164);
      });

      // Hook for real submission:
      const fakePost = () => new Promise((res) => setTimeout(res, 1500));

      fakePost().then(() => {
        alert('Form submitted successfully! Redirecting to payment...');
        // e.g., window.location.assign('/pay');
      }).finally(() => {
        if (splash) splash.style.display = 'none';
      });
    }
  };

  // -----------------------------
  // Boot
  // -----------------------------
  document.addEventListener('DOMContentLoaded', function () {
    // Init modules if their markup is present
    Listing.init();
    Quote.init();
    Steps.init();

    // Init phone globally in case some tel inputs exist outside forms
    Phone.initAll();

    // Public functions for legacy inline handlers (existing HTML uses these)
    window.showConfirmPopup = (level) => Listing.showConfirm(level);
    window.closePopup = () => Listing.closePopup();
    window.proceedWithBooking = () => Listing.proceed();

    // Send initial height for iframe scenarios
    postFrameHeight();
    window.addEventListener('load', postFrameHeight);
    window.addEventListener('resize', postFrameHeight);
    if ('ResizeObserver' in window) {
      const ro = new ResizeObserver(postFrameHeight);
      ro.observe(document.body);
    }
  });

})();
